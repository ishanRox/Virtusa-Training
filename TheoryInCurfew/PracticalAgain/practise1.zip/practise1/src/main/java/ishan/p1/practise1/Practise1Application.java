package ishan.p1.practise1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practise1Application {

	public static void main(String[] args) {
		SpringApplication.run(Practise1Application.class, args);
	}

}
