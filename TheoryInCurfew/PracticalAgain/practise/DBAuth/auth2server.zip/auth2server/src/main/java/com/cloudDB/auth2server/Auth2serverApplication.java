package com.cloudDB.auth2server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Auth2serverApplication {

	public static void main(String[] args) {
		SpringApplication.run(Auth2serverApplication.class, args);
	}

}
