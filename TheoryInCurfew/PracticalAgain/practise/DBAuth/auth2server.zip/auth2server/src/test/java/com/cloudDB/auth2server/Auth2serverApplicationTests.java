package com.cloudDB.auth2server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Auth2serverApplicationTests {

	@Test
	void contextLoads() {
	}

}
