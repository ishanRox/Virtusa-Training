package com.configConsumer.test.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
