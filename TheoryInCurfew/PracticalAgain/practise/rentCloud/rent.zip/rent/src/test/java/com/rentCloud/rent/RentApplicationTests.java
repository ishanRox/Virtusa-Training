package com.rentCloud.rent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentApplicationTests {

	@Test
	void contextLoads() {
	}

}
