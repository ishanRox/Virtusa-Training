#!/bin/bash

#start time in seconds
start=$(date +%s)

start=$1
end=$2

echo "Bash script initiated invoking python script"
echo "going to simulate $start to $end devices"
echo "______________________________________________________"
for i in $(seq -f "%04g" $start $end); do
    echo "device $i"
    python x.py "OHIOLT$i" &
done
wait

#end time and calculate total running time
end=$(date +%s)
runtime=$((end - start))

echo "Bash :- completed all process $runtime seconds"
