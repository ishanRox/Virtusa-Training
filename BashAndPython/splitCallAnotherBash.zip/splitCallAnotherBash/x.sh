echo "____________________"
echo "different bash call"
echo $1
echo $2
echo $3
sleep 1
echo "______________________"