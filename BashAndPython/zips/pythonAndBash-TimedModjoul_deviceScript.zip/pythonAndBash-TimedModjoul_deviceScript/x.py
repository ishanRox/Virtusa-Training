import sys

print(sys.argv, " recived ...")
print("python script is running....")
