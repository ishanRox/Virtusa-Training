
To run bash file use - ./multi.sh
replace python script name with your python script name - python x.py
set number to devicecount no of times that python script needed to run - deviceCount=100
