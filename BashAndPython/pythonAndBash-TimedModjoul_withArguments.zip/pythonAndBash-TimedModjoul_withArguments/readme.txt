
To run bash file use - ./multi.sh
replace python script name with your python script name - python x.py
