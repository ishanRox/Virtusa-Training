import sys

print(sys.argv)
print("python script is running....")
