package com.auth.ishan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IshanApplication {

	public static void main(String[] args) {
		SpringApplication.run(IshanApplication.class, args);
	}

}
